package net.simplifiedlearning.volleymysqlexample;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    //this is the JSON Data URL
    //make sure you are using the correct ip else it will not work
    private String URL_PRODUCTS = "http://192.168.2.5/MyApi/TestApi4.php?id=8902080000227";
    private String URL_PRODUCTS2 = "http://192.168.2.5/MyApi/warning_info_barcode.php";

    //a list to store all the products
    List<Product> productList;

    //the recyclerview
    RecyclerView recyclerView;

    public static ArrayList<String> holder = new ArrayList<String>();
    public static ArrayList<String> holder2 = new ArrayList<String>();
    public static ArrayList<String> holder3;

    private Button button;

    // private static int SPLASH_TIME_OUT= 4000;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //getting the recyclerview from xml
        recyclerView = findViewById(R.id.recylcerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        Bundle bundle = getIntent().getExtras();

        if (bundle.getString("SCAN_RESULTS") != null) {
            String v = bundle.getString("SCAN_RESULTS");
            Toast.makeText(getApplicationContext(), "value" + v, Toast.LENGTH_SHORT).show();
            URL_PRODUCTS = "http://192.168.2.5/MyApi/TestApi4.php?id=" + v;

            //TODO here get the string stored in the string variable and do
            // setText() on userName
        }
        //initializing the productlist
        productList = new ArrayList<>();

        //this method will fetch and parse json
        //to display it in recyclerview
        // loadProducts();

        /*button = (Button) findViewById(R.id.button3);

        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub

                        openActivity();
                    }
        });*/


                /*
                 * Intent is just like glue which helps to navigate one activity
                 * to another.
                 Intent intent = new Intent(MainActivity.this,
                        List.class);
                startActivity(intent); */// startActivity allow you to move


        fetchdata();
        // fetchdata2();
        //commonelements();
    }


  /*  private void loadProducts() {

        /*
         * Creating a String Request
         * The request type is GET defined by first parameter
         * The URL is defined in the second parameter
         * Then we have a Response Listener and a Error Listener
         * In response listener we will get the JSON response as a String
         * */
       /* StringRequest stringRequest = new StringRequest(Request.Method.GET, URL_PRODUCTS,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            //converting the string to json array object
                            JSONArray array = new JSONArray(response);

                            //traversing through all the object
                            for (int i = 0; i < array.length(); i++) {

                                //getting product object from json array

                                JSONObject product = array.getJSONObject(i);


                                //adding the product to product list
                                productList.add(new Product(
                                        product.getString("note"),
                                        product.getString("image")

                                ) ) ;}



                            Toast.makeText(getApplicationContext(),"Hua",Toast.LENGTH_SHORT).show();



                            //creating adapter object and setting it to recyclerview
                            ProductsAdapter adapter = new ProductsAdapter(MainActivity.this, productList);
                            recyclerView.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });

        //adding our stringrequest to queue
        Volley.newRequestQueue(this).add(stringRequest);*/


   public void fetchdata()

    {

        class dbmanager extends AsyncTask<String, Void,String>
        {

            public void onPostExecute(String data)
            {
                try {
                    JSONObject jo = null;
                    holder.clear();
                    //ARRAYLIST 2
                    JSONArray ja = new JSONArray(data);


                    for (int i = 0; i < ja.length(); i++) {

                        //getting product object from json array

                        JSONObject product = ja.getJSONObject(i);


                        //adding the product to product list
                        productList.add(new Product(
                                product.getString("note"),
                                product.getString("image")

                        ) ) ;}


                    for (int i =0; i<ja.length();i++) {
                        jo = ja.getJSONObject(i);
                        String content = jo.getString("bad_contents");
                        String[] replace=content.split(",");
                        int arraySize = replace.length;

                        Arrays.asList(replace);

                        for (int j = 0; j < arraySize; j++) {
                            holder.add((replace[j]));

                        }
                    }

                    Intent intent = new Intent(MainActivity.this, ExpandView.class);
                    intent.putExtra("FILES_TO_SEND", holder);

                    ProductsAdapter adapter = new ProductsAdapter(MainActivity.this, productList);
                    recyclerView.setAdapter(adapter);
                    startActivity(intent);


                    Toast.makeText(getApplicationContext(),"Hua shyad",Toast.LENGTH_SHORT).show();


                } catch(Exception ex){

                    Toast.makeText(getApplicationContext(),data,Toast.LENGTH_LONG).show();


                }
            }

            @Override
            public String doInBackground(String... strings) {
                //return null;
                try {
                    URL url = new URL (strings[0]);
                    HttpURLConnection conn =(HttpURLConnection)url.openConnection();
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuffer data = new StringBuffer();
                    String line;

                    while( (line = br.readLine())!=null)
                    {
                        data.append(line + "\n");
                    }
                    br.close();
                    return data.toString();

                }catch(Exception ex){

                    return ex.getMessage();

                }
            }
        }

        dbmanager obj = new dbmanager();
        obj.execute(URL_PRODUCTS);

    }

   /* public void fetchdata2()

    {

        class dbmanager extends AsyncTask<String, Void,String>
        {

            public void onPostExecute(String data)
            {
                try {
                    JSONArray ja = new JSONArray(data);
                    JSONObject jo = null;
                    holder2.clear();
                    //ARRAYLIST 2
                    for (int i =0; i<ja.length();i++) {
                        jo = ja.getJSONObject(i);
                        String name = jo.getString("Warning");
                        holder2.add(name);

                        Toast.makeText(getApplicationContext(),"Hope hua",Toast.LENGTH_SHORT).show();

                    }

                } catch(Exception ex){

                    Toast.makeText(getApplicationContext(),data,Toast.LENGTH_LONG).show();


                }
            }

            @Override
            public String doInBackground(String... strings) {
                //return null;
                try {
                    URL url = new URL (strings[0]);
                    HttpURLConnection conn =(HttpURLConnection)url.openConnection();
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuffer data = new StringBuffer();
                    String line;

                    while( (line = br.readLine())!=null)
                    {
                        data.append(line + "\n");
                    }
                    br.close();
                    return data.toString();

                }catch(Exception ex){

                    return ex.getMessage();

                }
            }
        }

        dbmanager obj = new dbmanager();
        obj.execute(URL_PRODUCTS2);

    }*/

  /*  public void commonelements()
    {
        for (int j = 0; j < holder.size() ; j++) {
            for (int i = 0; i < holder2.size(); i++) {
                String instrumentList = holder2.get(i) ;
                if (holder.get(j).equals(instrumentList)) {
                    holder3 = new ArrayList<String>() ;
                    holder3.add(instrumentList);
                    Intent intent = new Intent(MainActivity.this, ExpandView.class);
                    intent.putExtra("FILES_TO_SEND", holder3);
                  //  startActivity(intent);
                }
            }
        }

    }*/

   /* public void openActivity(){

        Intent intent = new Intent(MainActivity.this, ExpandView.class);
        intent.putExtra("FILES_TO_SEND", holder3);
        startActivity(intent);

    }*/





}
